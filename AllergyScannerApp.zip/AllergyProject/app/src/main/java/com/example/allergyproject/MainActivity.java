package com.example.allergyproject;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private TextView tvResult;
    private Button btnScan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResult = findViewById(R.id.tvResult);
        btnScan = findViewById(R.id.btnScan);

        tvResult.setVisibility(View.GONE);

        btnScan.setOnClickListener(v -> {
            ScanOptions options = new ScanOptions();
            options.setPrompt("Place barcode inside the viewfinder");
            options.setBeepEnabled(true);
            options.setOrientationLocked(false);
            barcodeLauncher.launch(options);
        });
    }

    private final androidx.activity.result.ActivityResultLauncher<ScanOptions> barcodeLauncher = registerForActivityResult(
            new ScanContract(),
            result -> {
                if (result.getContents() != null) {
                    String scannedBarcode = result.getContents();
                    tvResult.setVisibility(View.VISIBLE);
                    tvResult.setText("Scanned: " + scannedBarcode + "\nChecking allergies...");
                    fetchAllergyInfo(scannedBarcode);
                } else {
                    tvResult.setVisibility(View.VISIBLE);
                    tvResult.setText("Scan cancelled");
                }
            }
    );

    private void fetchAllergyInfo(String barcode) {
        new Thread(() -> {
        }).start();
        try {
            
            URL url = new URL("http://192.168.1.107/food_checker.php?barcode=" + barcode);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                String allergyInfo = response.toString();
                runOnUiThread(() ->
                        tvResult.setText("Scanned: " + barcode + "\nAllergy info:\n" + allergyInfo)
                );
            } else {
                runOnUiThread(() ->
                        tvResult.setText("Server error: " + responseCode)
                );
            }

            connection.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
            runOnUiThread(() ->
                    tvResult.setText("Network error: " + e.getMessage())
            );
        }
    }
}
